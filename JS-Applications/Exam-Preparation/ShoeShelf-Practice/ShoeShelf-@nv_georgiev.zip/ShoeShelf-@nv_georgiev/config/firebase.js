// Your web app's Firebase configuration
var firebaseConfig = {
  apiKey: 'AIzaSyCBYYOaZDPynnu6DSKpFT9hJ1Ig588A7Dw',
  authDomain: 'examprep-c4114.firebaseapp.com',
  databaseURL: 'https://examprep-c4114.firebaseio.com',
  projectId: 'examprep-c4114',
  storageBucket: 'examprep-c4114.appspot.com',
  messagingSenderId: '25535886611',
  appId: '1:25535886611:web:e97c2bda853ac60723d6e6',
  measurementId: 'G-PRGE3DL3J1',
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
