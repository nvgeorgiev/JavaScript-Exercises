export default {
  header: './views/common/header.hbs',
  footer: './views/common/footer.hbs',
};
